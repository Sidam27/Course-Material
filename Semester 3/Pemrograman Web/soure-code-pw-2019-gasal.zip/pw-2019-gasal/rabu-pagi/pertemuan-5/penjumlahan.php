<html>
    <body>
        <form action="sum.php" method="get">
            Bil a: <input type="text" name="a"><br>
            Bil b: <input type="text" name="b"><br>
            <input type="submit">
        </form>
    </body>
</html>