<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$a = 10;
$b = 20;
$c = $a * $b;

print "A: ".$a;
print "\n";
print "B: ".$b;
print "\n";
print "Hasil perkalian: ".$c;
print "\n";
