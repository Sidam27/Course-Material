<html>
    <body>
        <?php
            // area php
        
            echo 'Web php pertama';
        ?>
    </body>
</html>