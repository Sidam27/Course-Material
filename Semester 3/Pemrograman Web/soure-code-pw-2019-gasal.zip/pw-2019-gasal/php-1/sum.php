<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$a = $_GET["a"];
$b = $_GET["b"];
$hasil = $a + $b;


print "Bilangan a: ".$a;
print "<br>";
print "Bilangan b: ".$b;
print "<br>";
print "Hasil penjumlahan: $hasil";