<html>
    <body>
        <form method="post" action="sum_post.php">
            Bilangan a: <input type="text" name="a"><br>
            Bilangan b: <input type="text" name="b"><br>
            <input type="submit">
        </form>
    </body>
</html>